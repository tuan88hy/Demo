package net.hytech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MssqlMyBatisApplicationTests {

	@Test
	void contextLoads() {
	}

}
