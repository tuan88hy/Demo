package net.hytech.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import net.hytech.model.Idcode;
import net.hytech.service.IdcodeService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/Demo")
public class IdcodeController {
	@Autowired
	IdcodeService idcodeService;
	
	
	@GetMapping("/selectAll")
	public List<Idcode> selectAll()
	{
		return idcodeService.selectAll();
	}
	
	@RequestMapping(value = "/addIDCode", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public void insert(Integer id,String name )
	{
		Idcode tmp = new Idcode();
		tmp.setName(name);
		tmp.setId(id);
		
		idcodeService.insert(tmp);
		
	}
	
	@RequestMapping(value = "/updateIDCode", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public void update(Integer id,String name )
	{
		Idcode tmp = new Idcode();
		tmp.setName(name);
		tmp.setId(id);
		
		idcodeService.updateByPrimaryKey(tmp);
		
	}
	
	@RequestMapping(value = "/deleteIDCode", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public void delete(Integer id )
	{
		idcodeService.deleteByPrimaryKey(id);
		
	}
	
	
}
