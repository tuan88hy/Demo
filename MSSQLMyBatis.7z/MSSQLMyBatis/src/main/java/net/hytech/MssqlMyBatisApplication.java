package net.hytech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MssqlMyBatisApplication {

	public static void main(String[] args) {
		SpringApplication.run(MssqlMyBatisApplication.class, args);
	}

}
