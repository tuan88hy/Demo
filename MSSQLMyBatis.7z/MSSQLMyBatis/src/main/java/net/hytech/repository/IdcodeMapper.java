package net.hytech.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import net.hytech.model.Idcode;

@Mapper
@Repository
public interface IdcodeMapper {
    
    
    List<Idcode> selectAll();
    void insert(Idcode tmp);
    void updateByPrimaryKey(Idcode tmp);
    void deleteByPrimaryKey(int id);
    

}