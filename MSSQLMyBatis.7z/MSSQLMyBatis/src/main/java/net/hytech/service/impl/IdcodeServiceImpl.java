package net.hytech.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.hytech.model.Idcode;
import net.hytech.repository.IdcodeMapper;
import net.hytech.service.IdcodeService;

@Service
public class IdcodeServiceImpl implements IdcodeService {

	@Autowired
	IdcodeMapper idcodeMapper;
	
	@Override
	public List<Idcode> selectAll() {
		// TODO Auto-generated method stub
		return idcodeMapper.selectAll();
	}

	@Override
	public void insert(Idcode tmp) {
		// TODO Auto-generated method stub
		idcodeMapper.insert(tmp);
	}

	@Override
	public void updateByPrimaryKey(Idcode tmp) {
		// TODO Auto-generated method stub
		idcodeMapper.updateByPrimaryKey(tmp);
	}

	@Override
	public void deleteByPrimaryKey(int id) {
		// TODO Auto-generated method stub
		idcodeMapper.deleteByPrimaryKey(id);
	}

}
