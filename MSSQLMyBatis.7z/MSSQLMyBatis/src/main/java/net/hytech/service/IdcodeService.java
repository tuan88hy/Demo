package net.hytech.service;

import java.util.List;

import net.hytech.model.Idcode;


public interface IdcodeService {
	List<Idcode> selectAll();
	void insert(Idcode tmp);
	void updateByPrimaryKey(Idcode tmp);
	void deleteByPrimaryKey(int id);
}
